# Sales Insights Native App

Versión didáctica 1.0.

La aplicación instala dentro del objeto `APPLICATION`:

- Un catálogo interno de objetivos por región.
- Una vista pública para consumidores.
- Una función para calcular el porcentaje de cumplimiento.
- Un procedimiento para guardar una nota del consumidor.
- Un application role llamado `APP_USER`.

La aplicación no solicita privilegios globales, no crea warehouses y no accede a datos externos del consumidor.
