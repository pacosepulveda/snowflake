# Sales Insights Native App

Versión didáctica 2.0.

Cambios respecto a la versión 1.0:

- Prioridad por región.
- Gap frente a una referencia de 1.000.
- Nuevos objetivos para Norte y Este.
- Función `RECOMMEND_ACTION`.
- Conservación de las notas creadas por el consumidor.

La actualización reutiliza la tabla de notas mediante `CREATE TABLE IF NOT EXISTS`, demostrando que el estado interno puede conservarse durante un upgrade.
